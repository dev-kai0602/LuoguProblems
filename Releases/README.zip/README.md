# [P14924 [GESP202512 八级] 宝石项链](https://www.luogu.com.cn/problem/P14924)

## 目录

 1) [读题](#读题)
 2) [分析](#分析)
 3) [思路](#思路)
    1. [暴力](#1-暴力)
    2. [再次分析](#2-再次分析)
    3. [再次实现](#3-再次实现)

## 读题

先看题目描述：

## 题目描述

> 小 A 有一串包含 $n$ 枚宝石的宝石项链，这些宝石按照在项链中的顺序依次以 $1,2,\ldots,n$ 编号，第 $n$ 枚宝石与第 $1$ 枚宝石相邻。项链由 $m$ 种宝石组成，其中第 $i$ 枚宝石种类为 $t_i$。小 A 想将宝石项链分给他的好朋友们。具体而言，小 A 会将项链划分为若干**连续段**，并且需要保证每段都包含全部 $m$ 种宝石。请帮小 A 计算在满足条件的前提下，宝石项链最多可以划分为多少段。

<details>
<summary>详细信息</summary>

![P14924题目](./images/5.png)

</details>

读题可得，我们有一条项链，要把它分成很多块，每一块至少包含 $m$ 种宝石。所以一块可以有很多个种类相同的宝石，但得要包含 $m$ 种宝石，如下面这个就是合法的一块(当m=3时)：

> 1 1 2 2 3 3

这里有6枚宝石，3种不同的宝石

## 分析

我们不妨先分析题目，可以发现题目有以下难点：

| 问题 | 本质 |
|------|------|
| 环形从哪开始切？ | 起点未知 |
| 从 i 出发下一段最短到哪？ | 局部最优跳跃 |
| 枚举起点后如何快速跳完一圈？ | 多次跳跃加速 |

## 思路

读题，可得项链应该是这样的：

![项链图片](./images/1.jpg)

环有点难处理，所以我们可以通过在后面接一条相同的元素，把它转化为一条链：

![化环为链](./images/2.jpg)

### 1. 暴力

**遇到这样的题先不要慌，写个暴力得部分分**  
暴力枚举每个起点，再划分，然后看看可不可以（即每一段都要包含 $m$ 种宝石）

核心代码；
``` cpp
// 枚举每个起点
for (int i=1; i<=n; i++) {
    pos=i;
    b = 0;
    // 贪心划分，直到无法继续
    while (pos < i+n) {
    	memset(cnt, 0, sizeof(cnt));
        kinds=0;
        e=pos;
        // 向后扩展，直到包含所有 m 种宝石
        while (e<i+n && kinds<m) {
            int t=a[e];
            if (cnt[t]==0) {
                kinds++;
			}
            cnt[t]++;
            e++;
        }
        if (kinds<m) {
        	break; // 无法形成合法段
		}
        b++;
        pos=e; // 从下一个位置继续
    }
    ans=max(ans, b);
}
```

<details>
<summary>全部代码</summary>
<pre>
#include "bits/stdc++.h"
using namespace std;

int n, m, pos, b, kinds, e, ans;
int cnt[100005];

signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	
    cin >> n >> m;
    vector<int> a(2 * n + 1);
    for (int i = 1; i <= n; i++) {
        cin>>a[i];
        a[n+i]=a[i]; // 转环为链 
    }

    // 枚举每个起点
    for (int i=1; i<=n; i++) {
        pos=i;
        b = 0;
        // 贪心划分，直到无法继续
        while (pos < i+n) {
        	memset(cnt, 0, sizeof(cnt));
            kinds=0;
            e=pos;
            // 向后扩展，直到包含所有 m 种宝石
            while (e<i+n && kinds<m) {
                int t=a[e];
                if (cnt[t]==0) {
                	kinds++;
				}
                cnt[t]++;
                e++;
            }
            if (kinds<m) {
            	break; // 无法形成合法段
			}
            b++;
            pos=e; // 从下一个位置继续
        }
        ans=max(ans, b);
    }
    cout<<ans<<"\n";
    
    return 0;
}
</pre>
</details>

提交到洛谷可得

[![暴力得分](./images/3.png)](https://www.luogu.com.cn/record/300505152)

暴力的时间复杂度为 *O(n²)* ，所以会超时，只得了30分

### 2. 再次分析

又卡了，别急，我们再次分析一下可得：  
**从位置 i 出发，最短的合法段终点索引（下文用`jump[i]`代替）是唯一确定的**。  
Why？ 因为要"段数最大"，每段就必须"尽可能短"。而"最短的包含全部 m 种的区间"是唯一的（双指针可求）。所以从 i 出发，下一段起点必然是 `jump[i]`，没有选择余地。  
这个观察是**整道题的分水岭**。有了它，问题就变成了：

> 在一张"跳跃图"上，从每个起点出发，最多能跳几步（不能超过 i+n）？  

所以，我们可以用双指针维护窗口 `[i, j-1]`，`cnt` 数组记录每种宝石出现次数，`kinds` 记录当前窗口内种类数：

- 当 `kinds < m` 时，右指针 `j` 右移，纳入新宝石；
- 当 `kinds == m` 时，`f[i][0] = j`，然后左指针 `i` 右移，尝试缩窗口。

这个过程**每个元素最多进窗口一次、出窗口一次**，时间复杂度为O(n)。  
  
PS：`j` 是**单调不回退**的。因为 i 右移后，窗口只会变小，j 不可能往左走。所以滑动窗口能 O(n) 。

如果直接模拟跳跃，从 i 出发最坏要跳 n 次（每段长度是 1），总复杂度 O(n²)。[倍增](https://oi-wiki.org/basic/binary-lifting/)便起作用了，**把"跳 k 步"压缩成 O(log k)**。

定义 `f[i][k]` 为从 i 跳 `2^k` 步后的位置（即 f[i][j] 表示从位置 i 开始，连续划分出 2^j 个合法段之后，下一段的起始位置）：

``` cpp
f[i][0] = jump[i]
f[i][k] = f[ f[i][k-1] ][k-1]
```

统计答案时，从大到小枚举 k，**能跳就跳**（前提是不超过 `i+n`），最后统计就可以了。

### 3. 再次实现

``` cpp
#include <bits/stdc++.h>
using namespace std;

const int N = 2e5+5;
const int LOG = 20; // 倍增表的层数，即 2^20 ，大概100万步
int a[N], f[N][LOG+1], cnt[N];
int n, m;

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	
	cin >> n >> m;
	for (int i=1; i<=n; i++) {
		cin >> a[i];
	}
	
    // 化环为链
	for (int i=1; i<=n; i++) {
		a[n+i] = a[i];
	}
	
    // 给 f 初始化，找从该起点往后一个块的第一个没被占用的索引
	int kinds = 0;
	for (int i=1, j=1; i<=2*n; i++) {
        // while 循环找可行的区间
		while (j <= 2*n && kinds < m) {
			cnt[a[j]]++;
			if (cnt[a[j]] == 1) {
				kinds++;
			}
			j++;
		}
        // 如果这个起点可行，就记录下
		if (kinds == m) {
			f[i][0] = j;
		}
		cnt[a[i]]--; // 左端点左移一位
		if (cnt[a[i]] == 0) {
			kinds--; // 如果少了一种(cnt[a[i]]==0)，就把种类减一
		}
	}
	
    // 开始算
	for (int k=1; k<=LOG; k++) {
		for (int i=1; i<=2*n; i++) {
            // 我如果要跳 2^j 步，可以拆成两个部分算 "先跳 2^{j-1} 步，再跳 2^{j-1} 步"
            // 为什么不写 `f[i][j] = f[i][j-1] + 2^{j-1}` ?
            // 因为跳一下的规则不是固定步长，而是由滑动窗口决定的，每跳一下，落点不同，下一步能跳多远也不同。所以不能简单用加法，必须逐段追踪位置。
			f[i][k] = f[ f[i][k-1] ][k-1];
		}
	}
	
	int ans=0;
	for (int i=1; i<=n; i++) {
		int limit = i+n; // 区间最大值
		int pos = i, res = 0; // pos 记录了当前位置，res为这次的结果
        // 遍历f
		for (int k=LOG; k>=0; k--) {
            // 可以跳
			if (f[pos][k] && f[pos][k] <= limit) {
				res += (1 << k); // 累计区间(跳了 2^k 个区间)
				pos = f[pos][k]; // 更新位置
			}
		}
		ans = max(ans, res); // 取所有答案的最大值
	}
	
	cout << ans << "\n";

	return 0;
}
```

现在全部AC了

[![全部AC](./images/4.png)](https://www.luogu.com.cn/record/300511819)

---

本文部分内容由 DeepSeek V4.1 Flash 生成，人类贡献大于 50%  
<sub><sub><sub><sub><sub>如果觉得我讲得好的话，请点一个start，谢谢喵~</sub></sub></sub></sub></sub>
